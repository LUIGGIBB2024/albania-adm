<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EncuestadoresController extends Controller
{
    //
}
